import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { idbStorage } from './storage'
import { uid, nowISO } from './utils'
import type {
  Escola, Turma, Equipe, Categoria, Atleta, Adversario, Campeonato,
  Partida, HorarioTreino, JogoAgendado, RegistroPresenca, AvaliacaoPeriodica,
  FormatoPartida,
} from './types'
import type { DadosNuvem } from './cloudSync'

/** Combina o local com o que veio da nuvem, por id — nunca descarta um item que já
 *  existe aqui (o local sempre "ganha" em caso de conflito de id), só soma o que
 *  faltava. Usado na recuperação/sincronização via Supabase. */
function mesclarPorId<T extends { id: string }>(local: T[], daNuvem: T[]): T[] {
  const mapa = new Map<string, T>()
  for (const item of local) mapa.set(item.id, item)
  for (const item of daNuvem) if (!mapa.has(item.id)) mapa.set(item.id, item)
  return Array.from(mapa.values())
}

interface RDState {
  escolas: Escola[]
  turmas: Turma[]
  equipes: Equipe[]
  categorias: Categoria[]
  atletas: Atleta[]
  adversarios: Adversario[]
  campeonatos: Campeonato[]
  partidas: Partida[]
  horariosTreino: HorarioTreino[]
  jogosAgendados: JogoAgendado[]
  presencas: RegistroPresenca[]
  avaliacoes: AvaliacaoPeriodica[]

  addEscola: (nome: string) => Escola
  deleteEscola: (id: string) => void
  restoreEscola: (id: string) => void

  addTurma: (escolaId: string, nome: string) => Turma
  deleteTurma: (id: string) => void
  restoreTurma: (id: string) => void

  addEquipe: (turmaId: string, nome: string) => Equipe
  deleteEquipe: (id: string) => void
  restoreEquipe: (id: string) => void

  addAtleta: (turmaId: string, nome: string, extra?: Partial<Atleta>) => Atleta
  updateAtleta: (id: string, patch: Partial<Atleta>) => void
  deleteAtleta: (id: string) => void
  restoreAtleta: (id: string) => void

  addAdversario: (nome: string) => Adversario
  addCampeonato: (nome: string, turmaId?: string) => Campeonato
  deleteCampeonato: (id: string) => void

  criarPartida: (turmaId: string, tipo: 'JOGO' | 'TREINO', formato: FormatoPartida, extra?: Partial<Partida>) => Partida
  atualizarPartida: (id: string, patch: Partial<Partida>) => void
  excluirPartida: (id: string) => void
  restaurarPartida: (id: string) => void

  addHorarioTreino: (turmaId: string, diaSemana: number, horario: string, local?: string) => HorarioTreino
  deleteHorarioTreino: (id: string) => void

  addJogoAgendado: (j: Omit<JogoAgendado, 'id' | 'createdAt'>) => JogoAgendado
  deleteJogoAgendado: (id: string) => void
  restoreJogoAgendado: (id: string) => void

  registrarPresenca: (turmaId: string, atletaId: string, data: string, presente: boolean) => void

  addAvaliacao: (a: Omit<AvaliacaoPeriodica, 'id'>) => AvaliacaoPeriodica

  mesclarDaNuvem: (dados: DadosNuvem) => void
}

const carimbo = () => nowISO()

export const useStore = create<RDState>()(
  persist(
    (setState, get) => ({
      escolas: [],
      turmas: [],
      equipes: [],
      categorias: [],
      atletas: [],
      adversarios: [],
      campeonatos: [],
      partidas: [],
      horariosTreino: [],
      jogosAgendados: [],
      presencas: [],
      avaliacoes: [],

      addEscola: (nome) => {
        const escola: Escola = { id: uid(), nome, createdAt: nowISO() }
        setState((s) => ({ escolas: [...s.escolas, escola] }))
        return escola
      },
      deleteEscola: (id) => {
        const ts = carimbo()
        setState((s) => ({
          escolas: s.escolas.map((e) => (e.id === id ? { ...e, deletedAt: ts } : e)),
          turmas: s.turmas.map((t) => (t.escolaId === id ? { ...t, deletedAt: ts } : t)),
          equipes: s.equipes.map((eq) =>
            s.turmas.some((t) => t.escolaId === id && t.id === eq.turmaId) ? { ...eq, deletedAt: ts } : eq
          ),
          atletas: s.atletas.map((a) =>
            s.turmas.some((t) => t.escolaId === id && t.id === a.turmaId) ? { ...a, deletedAt: ts } : a
          ),
        }))
      },
      restoreEscola: (id) => {
        setState((s) => ({
          escolas: s.escolas.map((e) => (e.id === id ? { ...e, deletedAt: undefined } : e)),
        }))
      },

      addTurma: (escolaId, nome) => {
        const turma: Turma = { id: uid(), escolaId, nome, createdAt: nowISO() }
        setState((s) => ({ turmas: [...s.turmas, turma] }))
        return turma
      },
      deleteTurma: (id) => {
        const ts = carimbo()
        setState((s) => ({
          turmas: s.turmas.map((t) => (t.id === id ? { ...t, deletedAt: ts } : t)),
          equipes: s.equipes.map((eq) => (eq.turmaId === id ? { ...eq, deletedAt: ts } : eq)),
          atletas: s.atletas.map((a) => (a.turmaId === id ? { ...a, deletedAt: ts } : a)),
          horariosTreino: s.horariosTreino.filter((h) => h.turmaId !== id),
          presencas: s.presencas.filter((p) => p.turmaId !== id),
        }))
      },
      restoreTurma: (id) => {
        setState((s) => ({ turmas: s.turmas.map((t) => (t.id === id ? { ...t, deletedAt: undefined } : t)) }))
      },

      addEquipe: (turmaId, nome) => {
        const equipe: Equipe = { id: uid(), turmaId, nome, createdAt: nowISO() }
        setState((s) => ({ equipes: [...s.equipes, equipe] }))
        return equipe
      },
      deleteEquipe: (id) => {
        const ts = carimbo()
        setState((s) => ({
          equipes: s.equipes.map((e) => (e.id === id ? { ...e, deletedAt: ts } : e)),
          categorias: s.categorias.filter((c) => c.equipeId !== id),
        }))
      },
      restoreEquipe: (id) => {
        setState((s) => ({ equipes: s.equipes.map((e) => (e.id === id ? { ...e, deletedAt: undefined } : e)) }))
      },

      addAtleta: (turmaId, nome, extra) => {
        const atleta: Atleta = { id: uid(), turmaId, nome, status: 'ATIVA', createdAt: nowISO(), ...extra }
        setState((s) => ({ atletas: [...s.atletas, atleta] }))
        return atleta
      },
      updateAtleta: (id, patch) => {
        setState((s) => ({ atletas: s.atletas.map((a) => (a.id === id ? { ...a, ...patch } : a)) }))
      },
      deleteAtleta: (id) => {
        const ts = carimbo()
        setState((s) => ({
          atletas: s.atletas.map((a) => (a.id === id ? { ...a, deletedAt: ts } : a)),
          presencas: s.presencas.filter((p) => p.atletaId !== id),
          avaliacoes: s.avaliacoes.filter((av) => av.atletaId !== id),
        }))
      },
      restoreAtleta: (id) => {
        setState((s) => ({ atletas: s.atletas.map((a) => (a.id === id ? { ...a, deletedAt: undefined } : a)) }))
      },

      addAdversario: (nome) => {
        const existente = get().adversarios.find((a) => a.nome.toLowerCase() === nome.toLowerCase())
        if (existente) return existente
        const adv: Adversario = { id: uid(), nome, createdAt: nowISO() }
        setState((s) => ({ adversarios: [...s.adversarios, adv] }))
        return adv
      },

      addCampeonato: (nome, turmaId) => {
        const camp: Campeonato = { id: uid(), nome, turmaId, createdAt: nowISO() }
        setState((s) => ({ campeonatos: [...s.campeonatos, camp] }))
        return camp
      },
      deleteCampeonato: (id) => {
        const ts = carimbo()
        setState((s) => ({ campeonatos: s.campeonatos.map((c) => (c.id === id ? { ...c, deletedAt: ts } : c)) }))
      },

      criarPartida: (turmaId, tipo, formato, extra) => {
        const partida: Partida = {
          id: uid(),
          tipo,
          turmaId,
          formato,
          data: nowISO().slice(0, 10),
          status: 'EM_ANDAMENTO',
          setsPartida: [],
          setsGanhosCasa: 0,
          setsGanhosAdversario: 0,
          createdAt: nowISO(),
          ...extra,
        }
        setState((s) => ({ partidas: [...s.partidas, partida] }))
        return partida
      },
      atualizarPartida: (id, patch) => {
        setState((s) => ({ partidas: s.partidas.map((p) => (p.id === id ? { ...p, ...patch } : p)) }))
      },
      excluirPartida: (id) => {
        setState((s) => ({ partidas: s.partidas.map((p) => (p.id === id ? { ...p, deletedAt: carimbo() } : p)) }))
      },
      restaurarPartida: (id) => {
        setState((s) => ({ partidas: s.partidas.map((p) => (p.id === id ? { ...p, deletedAt: undefined } : p)) }))
      },

      addHorarioTreino: (turmaId, diaSemana, horario, local) => {
        const h: HorarioTreino = { id: uid(), turmaId, diaSemana, horario, local }
        setState((s) => ({ horariosTreino: [...s.horariosTreino, h] }))
        return h
      },
      deleteHorarioTreino: (id) => {
        setState((s) => ({ horariosTreino: s.horariosTreino.filter((h) => h.id !== id) }))
      },

      addJogoAgendado: (j) => {
        const jogo: JogoAgendado = { ...j, id: uid(), createdAt: nowISO() }
        setState((s) => ({ jogosAgendados: [...s.jogosAgendados, jogo] }))
        return jogo
      },
      deleteJogoAgendado: (id) => {
        setState((s) => ({ jogosAgendados: s.jogosAgendados.map((j) => (j.id === id ? { ...j, deletedAt: carimbo() } : j)) }))
      },
      restoreJogoAgendado: (id) => {
        setState((s) => ({ jogosAgendados: s.jogosAgendados.map((j) => (j.id === id ? { ...j, deletedAt: undefined } : j)) }))
      },

      registrarPresenca: (turmaId, atletaId, data, presente) => {
        setState((s) => {
          const existente = s.presencas.find((p) => p.turmaId === turmaId && p.atletaId === atletaId && p.data === data)
          if (existente) {
            return { presencas: s.presencas.map((p) => (p.id === existente.id ? { ...p, presente } : p)) }
          }
          return { presencas: [...s.presencas, { id: uid(), turmaId, atletaId, data, presente }] }
        })
      },

      addAvaliacao: (a) => {
        const av: AvaliacaoPeriodica = { ...a, id: uid() }
        setState((s) => ({ avaliacoes: [...s.avaliacoes, av] }))
        return av
      },

      mesclarDaNuvem: (dados) => {
        setState((s) => ({
          escolas: mesclarPorId(s.escolas, dados.escolas),
          turmas: mesclarPorId(s.turmas, dados.turmas),
          atletas: mesclarPorId(s.atletas, dados.atletas),
          adversarios: mesclarPorId(s.adversarios, dados.adversarios),
          campeonatos: mesclarPorId(s.campeonatos, dados.campeonatos),
          partidas: mesclarPorId(s.partidas, dados.partidas),
          jogosAgendados: mesclarPorId(s.jogosAgendados, dados.jogosAgendados),
          avaliacoes: mesclarPorId(s.avaliacoes, dados.avaliacoes),
        }))
      },
    }),
    {
      name: 'rdsports-storage',
      storage: {
        getItem: async (name) => {
          const raw = await idbStorage.getItem(name)
          return raw ? JSON.parse(raw) : null
        },
        setItem: async (name, value) => {
          await idbStorage.setItem(name, JSON.stringify(value))
        },
        removeItem: async (name) => {
          await idbStorage.removeItem(name)
        },
      },
      version: 2,
    }
  )
)
