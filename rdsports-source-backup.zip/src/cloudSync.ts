// Sincronização principal do RDSports via Supabase — substitui o jsonbin.io.
// Ao logar: PUXA os dados que já existem na nuvem (recuperação dos dados antigos
// do Henrique, espelhados lá nas Rodadas 29/08–20/09/2026, antes da perda do código).
// Daí em diante: PUXA periodicamente (pra ver o que outros aparelhos mandaram) e
// EMPURRA (debounce) qualquer mudança local — cada aparelho loga com a mesma conta.
//
// Esquema normalizado (sets_partida/rallies/rally_eventos) é reaproveitado tal como
// documentado nas Fases 0–3 do histórico do projeto. Como o app reconstruído ainda
// não tem o conceito de Equipe/Categoria/Temporada na interface (só Escola → Turma →
// Atleta), este módulo provisiona automaticamente uma Equipe/Categoria "espelho" por
// Turma e uma Temporada ativa do ano atual — só pra satisfazer as colunas obrigatórias
// do schema antigo, sem expor isso na UI.
import { supabase } from './supabaseClient'
import type {
  Escola, Turma, Atleta, Adversario, Campeonato, Partida, SetPartida, Rally, RallyEvento,
  JogoAgendado, AvaliacaoPeriodica, FundamentoScout, ResultadoEvento, FormatoPartida,
} from './types'

export interface DadosNuvem {
  escolas: Escola[]
  turmas: Turma[]
  atletas: Atleta[]
  adversarios: Adversario[]
  campeonatos: Campeonato[]
  partidas: Partida[]
  jogosAgendados: JogoAgendado[]
  avaliacoes: AvaliacaoPeriodica[]
}

async function getOwnerId(): Promise<string | null> {
  const { data } = await supabase.auth.getUser()
  return data.user?.id ?? null
}

// --- Provisionamento automático (equipe/categoria/temporada "espelho") ---
const temporadaCache = new Map<string, string>() // ownerId -> temporadaId
const equipeCache = new Map<string, string>() // turmaId -> equipeId
const categoriaCache = new Map<string, string>() // equipeId -> categoriaId
let adversarioTreinoId: string | null = null

async function getOrCreateTemporadaAtiva(ownerId: string): Promise<string> {
  const cached = temporadaCache.get(ownerId)
  if (cached) return cached
  const ano = new Date().getFullYear()
  const { data: existente } = await supabase.from('temporadas').select('id').eq('owner_id', ownerId).eq('ano', ano).maybeSingle()
  if (existente) { temporadaCache.set(ownerId, existente.id); return existente.id }
  const { data: criada, error } = await supabase.from('temporadas').insert({ owner_id: ownerId, ano, ativa: true }).select('id').single()
  if (error || !criada) throw error ?? new Error('Falha ao criar temporada')
  temporadaCache.set(ownerId, criada.id)
  return criada.id
}

async function getOrCreateEquipeDaTurma(ownerId: string, turma: Turma): Promise<string> {
  const cached = equipeCache.get(turma.id)
  if (cached) return cached
  const { data: existente } = await supabase.from('equipes').select('id').eq('owner_id', ownerId).eq('turma_id', turma.id).maybeSingle()
  if (existente) { equipeCache.set(turma.id, existente.id); return existente.id }
  const { data: criada, error } = await supabase
    .from('equipes')
    .insert({ owner_id: ownerId, escola_id: turma.escolaId, turma_id: turma.id, nome: turma.nome })
    .select('id').single()
  if (error || !criada) throw error ?? new Error('Falha ao criar equipe')
  equipeCache.set(turma.id, criada.id)
  return criada.id
}

async function getOrCreateCategoriaDaEquipe(ownerId: string, equipeId: string): Promise<string> {
  const cached = categoriaCache.get(equipeId)
  if (cached) return cached
  const { data: existente } = await supabase.from('categorias').select('id').eq('owner_id', ownerId).eq('equipe_id', equipeId).maybeSingle()
  if (existente) { categoriaCache.set(equipeId, existente.id); return existente.id }
  const { data: criada, error } = await supabase.from('categorias').insert({ owner_id: ownerId, equipe_id: equipeId, nome: 'Geral' }).select('id').single()
  if (error || !criada) throw error ?? new Error('Falha ao criar categoria')
  categoriaCache.set(equipeId, criada.id)
  return criada.id
}

async function getOrCreateAdversarioTreino(ownerId: string): Promise<string> {
  if (adversarioTreinoId) return adversarioTreinoId
  const { data: existente } = await supabase.from('adversarios').select('id').eq('owner_id', ownerId).eq('nome', 'Treino interno').maybeSingle()
  if (existente) { adversarioTreinoId = existente.id; return existente.id }
  const { data: criado, error } = await supabase.from('adversarios').insert({ owner_id: ownerId, nome: 'Treino interno' }).select('id').single()
  if (error || !criado) throw error ?? new Error('Falha ao criar adversário de treino')
  adversarioTreinoId = criado.id
  return criado.id
}

// --- PUSH: manda o estado local atual pra nuvem (upsert por id, nunca apaga nada lá) ---
export async function pushAll(estado: {
  escolas: Escola[]; turmas: Turma[]; atletas: Atleta[]; adversarios: Adversario[]
  campeonatos: Campeonato[]; partidas: Partida[]; jogosAgendados: JogoAgendado[]; avaliacoes: AvaliacaoPeriodica[]
}): Promise<void> {
  const ownerId = await getOwnerId()
  if (!ownerId) return

  if (estado.escolas.length) {
    await supabase.from('escolas').upsert(estado.escolas.map((e) => ({
      id: e.id, owner_id: ownerId, nome: e.nome, created_at: e.createdAt, deleted_at: e.deletedAt ?? null,
    })))
  }
  if (estado.turmas.length) {
    await supabase.from('turmas').upsert(estado.turmas.map((t) => ({
      id: t.id, owner_id: ownerId, escola_id: t.escolaId, nome: t.nome, created_at: t.createdAt, deleted_at: t.deletedAt ?? null,
    })))
  }
  if (estado.adversarios.length) {
    await supabase.from('adversarios').upsert(estado.adversarios.map((a) => ({
      id: a.id, owner_id: ownerId, nome: a.nome, created_at: a.createdAt,
    })))
  }
  if (estado.campeonatos.length) {
    await supabase.from('campeonatos').upsert(estado.campeonatos.map((c) => ({
      id: c.id, owner_id: ownerId, nome: c.nome, created_at: c.createdAt,
    })))
  }

  for (const a of estado.atletas) {
    await supabase.from('atletas').upsert({
      id: a.id, owner_id: ownerId, nome: a.nome,
      numero: a.numero && !Number.isNaN(Number(a.numero)) ? Number(a.numero) : null,
      posicao: a.posicaoPrincipal ?? 'SEIS_POR_ZERO', foto_url: a.fotoUrl ?? null,
      status: (a.status ?? 'ATIVA').toLowerCase(), created_at: a.createdAt, deleted_at: a.deletedAt ?? null,
    })
    const turma = estado.turmas.find((t) => t.id === a.turmaId)
    if (!turma) continue
    const equipeId = await getOrCreateEquipeDaTurma(ownerId, turma)
    const categoriaId = await getOrCreateCategoriaDaEquipe(ownerId, equipeId)
    const temporadaId = await getOrCreateTemporadaAtiva(ownerId)
    const { data: historicoAberto } = await supabase
      .from('atleta_equipe_historico').select('id')
      .eq('owner_id', ownerId).eq('atleta_id', a.id).eq('turma_id', turma.id).is('data_saida', null).maybeSingle()
    if (!historicoAberto) {
      await supabase.from('atleta_equipe_historico').insert({
        owner_id: ownerId, atleta_id: a.id, escola_id: turma.escolaId, turma_id: turma.id,
        equipe_id: equipeId, categoria_id: categoriaId, temporada_id: temporadaId,
      })
    }
  }

  for (const p of estado.partidas) {
    const turma = estado.turmas.find((t) => t.id === p.turmaId)
    if (!turma) continue
    const equipeId = await getOrCreateEquipeDaTurma(ownerId, turma)
    const categoriaId = await getOrCreateCategoriaDaEquipe(ownerId, equipeId)
    const temporadaId = await getOrCreateTemporadaAtiva(ownerId)
    const adversarioId = p.adversarioId ?? (await getOrCreateAdversarioTreino(ownerId))

    await supabase.from('partidas').upsert({
      id: p.id, owner_id: ownerId, temporada_id: temporadaId, escola_id: turma.escolaId, turma_id: turma.id,
      equipe_id: equipeId, categoria_id: categoriaId, adversario_id: adversarioId,
      campeonato_id: p.campeonatoId ?? null, tipo: p.tipo, data: p.data, local: p.local ?? null,
      campeonato: p.campeonato ?? null, observacoes: p.observacoes ?? null,
      status: p.status === 'FINALIZADA' ? 'FINALIZADA' : 'EM_ANDAMENTO',
      sets_ganhos_casa: p.setsGanhosCasa, sets_ganhos_adversario: p.setsGanhosAdversario,
      pontos_set_decisivo: p.formato === 'TRES_OBRIGATORIOS_25' ? 25 : 15,
      criada_em: p.createdAt, deleted_at: p.deletedAt ?? null,
    })

    for (const set of p.setsPartida) {
      await supabase.from('sets_partida').upsert({
        id: set.id, owner_id: ownerId, partida_id: p.id, numero: set.numero,
        placar_casa: set.placarCasa, placar_adversario: set.placarAdversario,
        finalizado: set.finalizado, vencedor: set.vencedor ?? null,
      })
      for (const rally of set.rallies) {
        await supabase.from('rallies').upsert({
          id: rally.id, owner_id: ownerId, set_id: set.id, numero: rally.numero,
          ponto: rally.pontoCasa ? 'CASA' : 'ADVERSARIO',
          placar_casa: rally.placarCasaApos, placar_adversario: rally.placarAdversarioApos,
        })
        let ordem = 0
        for (const ev of rally.eventos) {
          await supabase.from('rally_eventos').upsert({
            id: ev.id, owner_id: ownerId, rally_id: rally.id, ordem: ordem++,
            fundamento: ev.fundamento.toUpperCase(), atleta_id: ev.atletaId ?? null,
            resultado: ev.resultado, detalhe: ev.tipoErro ?? ev.tipoPontoAtaqueAdversario ?? null,
          })
        }
      }
    }
  }

  for (const j of estado.jogosAgendados) {
    const turma = estado.turmas.find((t) => t.id === j.turmaId)
    await supabase.from('eventos_calendario').upsert({
      id: j.id, owner_id: ownerId, tipo: 'JOGO', titulo: j.adversarioNome, data: j.data,
      hora_inicio: j.horario ?? null, local: j.local ?? null,
      equipe_id: turma ? await getOrCreateEquipeDaTurma(ownerId, turma) : null,
      created_at: j.createdAt,
    })
  }

  for (const av of estado.avaliacoes) {
    await supabase.from('avaliacoes').upsert({
      id: av.id, owner_id: ownerId, atleta_id: av.atletaId, data: av.data,
      periodo: av.periodo, notas: av.notas, observacoes: av.observacoes ?? null,
    })
  }
}

// --- PULL: lê tudo que existe na nuvem pra essa conta e remonta no formato local ---
export async function pullAll(): Promise<DadosNuvem | null> {
  const ownerId = await getOwnerId()
  if (!ownerId) return null

  const [escolasR, turmasR, equipesR, atletasR, historicoR, adversariosR, campeonatosR, partidasR, setsR, ralliesR, eventosR, calendarioR, avaliacoesR] =
    await Promise.all([
      supabase.from('escolas').select('*').eq('owner_id', ownerId),
      supabase.from('turmas').select('*').eq('owner_id', ownerId),
      supabase.from('equipes').select('*').eq('owner_id', ownerId),
      supabase.from('atletas').select('*').eq('owner_id', ownerId),
      supabase.from('atleta_equipe_historico').select('*').eq('owner_id', ownerId),
      supabase.from('adversarios').select('*').eq('owner_id', ownerId),
      supabase.from('campeonatos').select('*').eq('owner_id', ownerId),
      supabase.from('partidas').select('*').eq('owner_id', ownerId),
      supabase.from('sets_partida').select('*').eq('owner_id', ownerId),
      supabase.from('rallies').select('*').eq('owner_id', ownerId),
      supabase.from('rally_eventos').select('*').eq('owner_id', ownerId),
      supabase.from('eventos_calendario').select('*').eq('owner_id', ownerId),
      supabase.from('avaliacoes').select('*').eq('owner_id', ownerId),
    ])

  const escolas: Escola[] = (escolasR.data ?? []).map((e) => ({
    id: e.id, nome: e.nome, createdAt: e.created_at, deletedAt: e.deleted_at ?? undefined,
  }))
  const turmas: Turma[] = (turmasR.data ?? []).map((t) => ({
    id: t.id, escolaId: t.escola_id, nome: t.nome, createdAt: t.created_at, deletedAt: t.deleted_at ?? undefined,
  }))

  const equipeParaTurma = new Map<string, string>()
  for (const eq of equipesR.data ?? []) if (eq.turma_id) equipeParaTurma.set(eq.id, eq.turma_id)

  const historicoPorAtleta = new Map<string, Array<{ turma_id: string | null; data_entrada: string; data_saida: string | null }>>()
  for (const h of historicoR.data ?? []) {
    const lista = historicoPorAtleta.get(h.atleta_id) ?? []
    lista.push(h)
    historicoPorAtleta.set(h.atleta_id, lista)
  }
  function turmaAtualDoAtleta(atletaId: string): string | undefined {
    const lista = historicoPorAtleta.get(atletaId)
    if (!lista || lista.length === 0) return undefined
    const abertos = lista.filter((h) => !h.data_saida)
    const escolhido = [...(abertos.length ? abertos : lista)].sort((a, b) => (b.data_entrada ?? '').localeCompare(a.data_entrada ?? ''))[0]
    return escolhido?.turma_id ?? undefined
  }

  const atletas: Atleta[] = (atletasR.data ?? [])
    .map((a) => ({
      id: a.id, turmaId: turmaAtualDoAtleta(a.id) ?? '', nome: a.nome,
      numero: a.numero != null ? String(a.numero) : undefined,
      posicaoPrincipal: a.posicao ?? undefined, fotoUrl: a.foto_url ?? undefined,
      status: (a.status ? a.status.toUpperCase() : 'ATIVA') as Atleta['status'],
      createdAt: a.created_at, deletedAt: a.deleted_at ?? undefined,
    }))
    .filter((a) => a.turmaId)

  const adversariosData = adversariosR.data ?? []
  const adversarios: Adversario[] = adversariosData
    .filter((a) => a.nome !== 'Treino interno')
    .map((a) => ({ id: a.id, nome: a.nome, createdAt: a.created_at }))
  const campeonatos: Campeonato[] = (campeonatosR.data ?? []).map((c) => ({ id: c.id, nome: c.nome, createdAt: c.created_at }))

  const eventosPorRally = new Map<string, typeof eventosR.data>()
  for (const ev of eventosR.data ?? []) {
    const lista = eventosPorRally.get(ev.rally_id) ?? []
    lista.push(ev)
    eventosPorRally.set(ev.rally_id, lista)
  }
  const ralliesPorSet = new Map<string, typeof ralliesR.data>()
  for (const r of ralliesR.data ?? []) {
    const lista = ralliesPorSet.get(r.set_id) ?? []
    lista.push(r)
    ralliesPorSet.set(r.set_id, lista)
  }
  const setsPorPartida = new Map<string, typeof setsR.data>()
  for (const st of setsR.data ?? []) {
    const lista = setsPorPartida.get(st.partida_id) ?? []
    lista.push(st)
    setsPorPartida.set(st.partida_id, lista)
  }

  function fundamentoLocal(f: string): FundamentoScout {
    return f.toLowerCase() as FundamentoScout
  }
  function resultadoLocal(r: string): ResultadoEvento {
    const up = (r ?? '').toUpperCase()
    if (up === 'ACERTO' || up === 'BOM' || up === 'MEDIO' || up === 'ERRO' || up === 'EM_JOGO') return up as ResultadoEvento
    return 'EM_JOGO'
  }

  const partidas: Partida[] = (partidasR.data ?? [])
    .map((p) => {
      const sets: SetPartida[] = (setsPorPartida.get(p.id) ?? [])
        .slice().sort((a, b) => a.numero - b.numero)
        .map((st) => {
          const rallies: Rally[] = (ralliesPorSet.get(st.id) ?? [])
            .slice().sort((a, b) => a.numero - b.numero)
            .map((r) => {
              const eventos: RallyEvento[] = (eventosPorRally.get(r.id) ?? [])
                .slice().sort((a, b) => a.ordem - b.ordem)
                .map((ev, idx, arr) => ({
                  id: ev.id, atletaId: ev.atleta_id ?? undefined, fundamento: fundamentoLocal(ev.fundamento),
                  resultado: resultadoLocal(ev.resultado),
                  encerraRally: idx === arr.length - 1 ? (r.ponto === 'CASA' ? 'CASA' : 'ADVERSARIO') : null,
                  tipoErro: ev.detalhe ?? undefined, timestamp: r.horario,
                }))
              return {
                id: r.id, numero: r.numero, eventos, pontoCasa: r.ponto === 'CASA',
                placarCasaApos: r.placar_casa, placarAdversarioApos: r.placar_adversario,
              }
            })
          return {
            id: st.id, numero: st.numero, placarCasa: st.placar_casa, placarAdversario: st.placar_adversario,
            rallies, finalizado: st.finalizado, vencedor: st.vencedor ?? undefined,
          }
        })
      const turmaId = p.turma_id ?? (p.equipe_id ? equipeParaTurma.get(p.equipe_id) : undefined) ?? ''
      const formato: FormatoPartida = p.pontos_set_decisivo === 25 ? 'TRES_OBRIGATORIOS_25' : 'MELHOR_DE_5'
      return {
        id: p.id, tipo: (p.tipo ?? 'JOGO') as Partida['tipo'], turmaId,
        adversarioId: p.adversario_id ?? undefined,
        adversarioNome: adversariosData.find((a) => a.id === p.adversario_id)?.nome,
        campeonato: p.campeonato ?? undefined, campeonatoId: p.campeonato_id ?? undefined,
        formato, data: p.data, local: p.local ?? undefined,
        status: p.status === 'FINALIZADA' ? 'FINALIZADA' : 'EM_ANDAMENTO',
        setsPartida: sets, setsGanhosCasa: p.sets_ganhos_casa, setsGanhosAdversario: p.sets_ganhos_adversario,
        observacoes: p.observacoes ?? undefined, createdAt: p.criada_em, deletedAt: p.deleted_at ?? undefined,
      } satisfies Partida
    })
    .filter((p) => p.turmaId)

  const jogosAgendados: JogoAgendado[] = (calendarioR.data ?? [])
    .filter((e) => e.tipo === 'JOGO')
    .map((e) => ({
      id: e.id, turmaId: (e.equipe_id ? equipeParaTurma.get(e.equipe_id) : undefined) ?? '',
      adversarioNome: e.titulo, data: e.data, horario: e.hora_inicio ?? undefined, local: e.local ?? undefined,
      createdAt: e.created_at,
    }))
    .filter((j) => j.turmaId)

  const avaliacoes: AvaliacaoPeriodica[] = (avaliacoesR.data ?? []).map((av) => ({
    id: av.id, atletaId: av.atleta_id, data: av.data,
    periodo: (av.periodo ?? 'PERSONALIZADA') as AvaliacaoPeriodica['periodo'],
    notas: av.notas ?? {}, observacoes: av.observacoes ?? undefined,
  }))

  return { escolas, turmas, atletas, adversarios, campeonatos, partidas, jogosAgendados, avaliacoes }
}
