import { NavLink } from 'react-router-dom'
import { Home, School, BarChart3, Calendar, Trophy, Settings } from 'lucide-react'

const items = [
  { to: '/', label: 'Início', Icon: Home },
  { to: '/escolas', label: 'Escolas', Icon: School },
  { to: '/estatisticas', label: 'Estatísticas', Icon: BarChart3 },
  { to: '/calendario', label: 'Calendário', Icon: Calendar },
  { to: '/historico', label: 'Histórico', Icon: Trophy },
  { to: '/configuracoes', label: 'Config.', Icon: Settings },
]

export function SidebarNav() {
  return (
    <nav className="hidden md:flex flex-col gap-1 w-56 shrink-0 border-r border-[var(--rd-border)] p-3">
      {items.map((it) => (
        <NavLink
          key={it.to}
          to={it.to}
          className={({ isActive }) =>
            `flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${isActive ? 'bg-[var(--rd-gold)] text-[#1a1300]' : 'hover:bg-black/5 dark:hover:bg-white/10'}`
          }
        >
          <it.Icon size={18} strokeWidth={2.25} />
          {it.label}
        </NavLink>
      ))}
    </nav>
  )
}

export function BottomNav() {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 flex justify-between border-t border-[var(--rd-border)] bg-[var(--rd-surface)] px-2 py-1 z-40">
      {items.map((it) => (
        <NavLink
          key={it.to}
          to={it.to}
          className={({ isActive }) =>
            `flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg text-[11px] font-medium flex-1 ${isActive ? 'text-[var(--rd-gold-strong)]' : 'text-[var(--rd-text-dim)]'}`
          }
        >
          <it.Icon size={20} strokeWidth={2.25} />
          {it.label}
        </NavLink>
      ))}
    </nav>
  )
}
