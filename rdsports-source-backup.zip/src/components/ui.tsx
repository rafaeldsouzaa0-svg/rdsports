import type { ReactNode } from 'react'

export function PageTitle({ icon, title, subtitle, action }: { icon?: ReactNode; title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 mb-5 flex-wrap">
      <div>
        <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
          {icon && <span className="inline-flex shrink-0 rd-accent-text">{icon}</span>}
          {title}
        </h1>
        {subtitle && <p className="text-sm text-[var(--rd-text-dim)] mt-0.5">{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}

export function EmptyState({ icon, text, action }: { icon: ReactNode; text: string; action?: ReactNode }) {
  return (
    <div className="rd-card p-10 text-center text-[var(--rd-text-dim)] flex flex-col items-center gap-3">
      <span className="text-4xl inline-flex items-center justify-center opacity-70">{icon}</span>
      <p>{text}</p>
      {action}
    </div>
  )
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`rd-card p-4 ${className}`}>{children}</div>
}

export function Button({ children, variant = 'default', className = '', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default' | 'gold' | 'danger' }) {
  const cls = variant === 'gold' ? 'rd-btn rd-btn-gold' : variant === 'danger' ? 'rd-btn rd-btn-danger' : 'rd-btn'
  return <button className={`${cls} ${className}`} {...props}>{children}</button>
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block mb-3">
      <span className="block text-sm font-medium mb-1">{label}</span>
      {children}
    </label>
  )
}
