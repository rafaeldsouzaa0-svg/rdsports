// Modelo de dados do RDSports. Nomes de campo mantidos compatíveis com as versões
// anteriores do app (mesma estrutura já usada nos dados salvos no IndexedDB/nuvem
// dos aparelhos do Henrique), para que a reconstrução continue lendo os dados reais.

export type FundamentoScout =
  | 'saque' | 'recepcao' | 'ataque' | 'bloqueio' | 'levantamento' | 'defesa'

export type ResultadoEvento = 'ACERTO' | 'BOM' | 'MEDIO' | 'ERRO' | 'EM_JOGO'

export type Posicao = 'PONTA1' | 'PONTA2' | 'CENTRAL1' | 'CENTRAL2' | 'LEVANTADORA' | 'OPOSTA' | 'LIBERO' | 'SEIS_POR_ZERO'

export interface Escola {
  id: string
  nome: string
  createdAt: string
  deletedAt?: string
}

export interface Turma {
  id: string
  escolaId: string
  nome: string
  createdAt: string
  deletedAt?: string
}

export interface Equipe {
  id: string
  turmaId: string
  nome: string
  createdAt: string
  deletedAt?: string
}

export interface Categoria {
  id: string
  equipeId: string
  nome: string
  createdAt: string
}

export interface Atleta {
  id: string
  turmaId: string
  categoriaId?: string
  nome: string
  numero?: string
  posicaoPrincipal?: Posicao
  fotoUrl?: string
  status?: 'ATIVA' | 'AFASTADA' | 'TRANSFERIDA' | 'INATIVA'
  createdAt: string
  deletedAt?: string
}

export interface Adversario {
  id: string
  nome: string
  createdAt: string
}

export interface Campeonato {
  id: string
  nome: string
  turmaId?: string
  createdAt: string
  deletedAt?: string
}

/** Formato de disputa da partida — item pedido pelo Henrique em 27/09/2026:
 *  cada campeonato tem uma quantidade diferente de sets, então isso precisa ser
 *  configurável por partida (ou por padrão do professor), não fixo no código. */
export type FormatoPartida = 'MELHOR_DE_3' | 'TRES_OBRIGATORIOS_25' | 'MELHOR_DE_5'

export const FORMATOS_PARTIDA: { valor: FormatoPartida; label: string; descricao: string }[] = [
  { valor: 'MELHOR_DE_5', label: 'Melhor de 5 sets', descricao: 'Formato padrão: joga até um dos times fazer 3 sets (o 5º set, se houver, decide)' },
  { valor: 'MELHOR_DE_3', label: 'Melhor de 3 sets', descricao: 'Joga até um dos times fazer 2 sets' },
  { valor: 'TRES_OBRIGATORIOS_25', label: '3 sets obrigatórios de 25', descricao: 'Sempre disputa os 3 sets, todos até 25 pontos, mesmo se um time já tiver vencido antes' },
]

export const CONFIG_FORMATO: Record<FormatoPartida, { setsParaVencer: number; totalSets: number; pontosDecisivo: number; obrigaTodosOsSets: boolean }> = {
  MELHOR_DE_5: { setsParaVencer: 3, totalSets: 5, pontosDecisivo: 15, obrigaTodosOsSets: false },
  MELHOR_DE_3: { setsParaVencer: 2, totalSets: 3, pontosDecisivo: 15, obrigaTodosOsSets: false },
  TRES_OBRIGATORIOS_25: { setsParaVencer: 2, totalSets: 3, pontosDecisivo: 25, obrigaTodosOsSets: true },
}

export interface RallyEvento {
  id: string
  atletaId?: string
  fundamento: FundamentoScout
  resultado: ResultadoEvento
  encerraRally: 'CASA' | 'ADVERSARIO' | null
  tipoErro?: string
  tipoPontoAtaqueAdversario?: string
  zona?: string
  timestamp: string
}

export interface Rally {
  id: string
  numero: number
  eventos: RallyEvento[]
  pontoCasa: boolean
  placarCasaApos: number
  placarAdversarioApos: number
}

export interface SetPartida {
  id: string
  numero: number
  placarCasa: number
  placarAdversario: number
  rallies: Rally[]
  finalizado: boolean
  vencedor?: 'CASA' | 'ADVERSARIO'
}

export interface Partida {
  id: string
  tipo: 'JOGO' | 'TREINO'
  turmaId: string
  adversarioId?: string
  adversarioNome?: string
  campeonato?: string
  campeonatoId?: string
  formato: FormatoPartida
  data: string
  local?: string
  status: 'EM_ANDAMENTO' | 'FINALIZADA'
  setsPartida: SetPartida[]
  setsGanhosCasa: number
  setsGanhosAdversario: number
  observacoes?: string
  videoUrl?: string
  marcacoesVideo?: { tempo: string; nota: string }[]
  createdAt: string
  deletedAt?: string
}

export interface HorarioTreino {
  id: string
  turmaId: string
  diaSemana: number // 0-6, domingo=0
  horario: string // "HH:MM"
  local?: string
  deletedAt?: string
}

export interface JogoAgendado {
  id: string
  turmaId: string
  adversarioId?: string
  adversarioNome: string
  campeonatoId?: string
  data: string
  horario?: string
  local?: string
  checklist?: { item: string; feito: boolean }[]
  createdAt: string
  deletedAt?: string
}

export interface RegistroPresenca {
  id: string
  turmaId: string
  atletaId: string
  data: string
  presente: boolean
}

export interface AvaliacaoPeriodica {
  id: string
  atletaId: string
  data: string
  periodo: 'MENSAL' | 'BIMESTRAL' | 'TRIMESTRAL' | 'PERSONALIZADA'
  notas: Record<string, number>
  observacoes?: string
}

export const CRITERIOS_AVALIACAO_PADRAO = [
  'Saque', 'Recepção', 'Levantamento', 'Ataque', 'Bloqueio', 'Defesa',
  'Tática', 'Tomada de decisão', 'Comunicação', 'Posicionamento',
]
