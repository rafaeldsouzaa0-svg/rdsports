// Motor de regras do scout ao vivo.
//
// REGRA CRÍTICA (pedido do Henrique, confirmado de novo em 27/09/2026): o
// levantamento NUNCA marca ponto/fecha rally por conta própria — "Bom" e "Médio"
// são só um acréscimo estatístico pra levantadora (contam nas estatísticas dela),
// exatamente como a Recepção. Só o fundamento que efetivamente decide o rally
// (o Ataque ou o Bloqueio, normalmente) fecha o rally e soma ponto no placar.
// Um levantamento "Erro" (ex.: bola caiu no próprio campo, invasão etc.) é a
// única marcação de levantamento que fecha o rally, e fecha pro adversário.
import type { FundamentoScout, ResultadoEvento, Rally, RallyEvento, SetPartida, Partida, FormatoPartida } from './types'
import { CONFIG_FORMATO } from './types'
import { uid, nowISO } from './utils'

export function encerraRallyDe(fundamento: FundamentoScout, resultado: ResultadoEvento): 'CASA' | 'ADVERSARIO' | null {
  switch (fundamento) {
    case 'saque':
      if (resultado === 'ACERTO') return 'CASA' // ace
      if (resultado === 'ERRO') return 'ADVERSARIO'
      return null // EM_JOGO — saque bom, bola em jogo
    case 'recepcao':
      // Bom/Médio nunca fecham rally (só o ataque decide); Erro fecha pro adversário.
      return resultado === 'ERRO' ? 'ADVERSARIO' : null
    case 'levantamento':
      // FIX: igual à recepção — Bom/Médio são só estatística da levantadora,
      // nunca somam ponto nem fecham o rally. Só o Erro fecha (pro adversário).
      return resultado === 'ERRO' ? 'ADVERSARIO' : null
    case 'ataque':
      if (resultado === 'ACERTO') return 'CASA'
      if (resultado === 'ERRO') return 'ADVERSARIO'
      return null
    case 'bloqueio':
      if (resultado === 'ACERTO') return 'CASA' // bloqueio de ponto
      if (resultado === 'ERRO') return 'ADVERSARIO'
      return null
    case 'defesa':
      // Defesa mantém a bola em jogo; só conta erro (bola não defendida) como fechamento.
      return resultado === 'ERRO' ? 'ADVERSARIO' : null
  }
}

export function criarSet(numero: number): SetPartida {
  return { id: uid(), numero, placarCasa: 0, placarAdversario: 0, rallies: [], finalizado: false }
}

export function registrarEvento(
  set: SetPartida,
  fundamento: FundamentoScout,
  resultado: ResultadoEvento,
  atletaId?: string,
  detalhes?: Partial<RallyEvento>
): SetPartida {
  const encerra = encerraRallyDe(fundamento, resultado)
  const evento: RallyEvento = {
    id: uid(),
    atletaId,
    fundamento,
    resultado,
    encerraRally: encerra,
    timestamp: nowISO(),
    ...detalhes,
  }

  const rallyAtual = set.rallies[set.rallies.length - 1]
  const rallyEmAndamento = rallyAtual && rallyAtual.placarCasaApos === set.placarCasa && rallyAtual.placarAdversarioApos === set.placarAdversario && !encerraFoiRegistrado(rallyAtual)

  if (!encerra) {
    // Estatística registrada, mas o rally continua — anexa ao rally em andamento
    // (cria um se ainda não existir nenhum aberto).
    if (rallyEmAndamento) {
      const rallies = set.rallies.slice(0, -1)
      return { ...set, rallies: [...rallies, { ...rallyAtual, eventos: [...rallyAtual.eventos, evento] }] }
    }
    const novoRally: Rally = {
      id: uid(), numero: set.rallies.length + 1, eventos: [evento],
      pontoCasa: false, placarCasaApos: set.placarCasa, placarAdversarioApos: set.placarAdversario,
    }
    return { ...set, rallies: [...set.rallies, novoRally] }
  }

  // Fecha o rally e soma o ponto.
  const pontoCasa = encerra === 'CASA'
  const placarCasa = set.placarCasa + (pontoCasa ? 1 : 0)
  const placarAdversario = set.placarAdversario + (pontoCasa ? 0 : 1)

  let rallies: Rally[]
  if (rallyEmAndamento) {
    rallies = [
      ...set.rallies.slice(0, -1),
      { ...rallyAtual, eventos: [...rallyAtual.eventos, evento], pontoCasa, placarCasaApos: placarCasa, placarAdversarioApos: placarAdversario },
    ]
  } else {
    rallies = [
      ...set.rallies,
      { id: uid(), numero: set.rallies.length + 1, eventos: [evento], pontoCasa, placarCasaApos: placarCasa, placarAdversarioApos: placarAdversario },
    ]
  }

  return { ...set, placarCasa, placarAdversario, rallies }
}

function encerraFoiRegistrado(rally: Rally): boolean {
  return rally.eventos.some((e) => e.encerraRally !== null)
}

/** Quantos pontos são precisos para fechar ESTE set, dado o formato da partida. */
export function pontosParaFecharSet(formato: FormatoPartida, numeroSet: number): number {
  const cfg = CONFIG_FORMATO[formato]
  return numeroSet === cfg.totalSets ? cfg.pontosDecisivo : 25
}

export function setEstaFechado(set: SetPartida, formato: FormatoPartida): 'CASA' | 'ADVERSARIO' | null {
  const alvo = pontosParaFecharSet(formato, set.numero)
  const { placarCasa, placarAdversario } = set
  const diff = Math.abs(placarCasa - placarAdversario)
  if (placarCasa >= alvo && diff >= 2) return 'CASA'
  if (placarAdversario >= alvo && diff >= 2) return 'ADVERSARIO'
  return null
}

/** Depois de fechar um set, decide se a partida acabou — considerando o formato
 *  escolhido (item pedido pelo Henrique: cada campeonato tem um formato próprio):
 *  - Melhor de 3 / Melhor de 5: acaba assim que um lado atinge os sets necessários.
 *  - 3 sets obrigatórios de 25: sempre joga os 3 sets, mesmo que um lado já tenha
 *    vencido os 2 primeiros — só decide o resultado (não empata o placar de sets). */
export function partidaEstaFinalizada(formato: FormatoPartida, setsGanhosCasa: number, setsGanhosAdversario: number, setsJogados: number): boolean {
  const cfg = CONFIG_FORMATO[formato]
  if (cfg.obrigaTodosOsSets) return setsJogados >= cfg.totalSets
  return setsGanhosCasa >= cfg.setsParaVencer || setsGanhosAdversario >= cfg.setsParaVencer
}

export function resumoFormato(partida: Pick<Partida, 'formato'>): string {
  const cfg = CONFIG_FORMATO[partida.formato]
  if (partida.formato === 'TRES_OBRIGATORIOS_25') return '3 sets obrigatórios de 25 pontos'
  return `Melhor de ${cfg.totalSets} sets (decisivo a ${cfg.pontosDecisivo})`
}
