import { useEffect } from 'react'
import { HashRouter, Routes, Route } from 'react-router-dom'
import { SidebarNav, BottomNav } from './components/Nav'
import Dashboard from './pages/Dashboard'
import Escolas from './pages/Escolas'
import EscolaDetalhe from './pages/EscolaDetalhe'
import TurmaDetalhe from './pages/TurmaDetalhe'
import ModoJogo from './pages/ModoJogo'
import Relatorio from './pages/Relatorio'
import Historico from './pages/Historico'
import Estatisticas from './pages/Estatisticas'
import Calendario from './pages/Calendario'
import Configuracoes from './pages/Configuracoes'
import Login from './pages/auth/Login'
import Cadastro from './pages/auth/Cadastro'
import RecuperarSenha from './pages/auth/RecuperarSenha'
import RedefinirSenha from './pages/auth/RedefinirSenha'
import { initSyncManager } from './syncManager'

export default function App() {
  useEffect(() => {
    initSyncManager()
  }, [])

  return (
    <HashRouter>
      <div className="flex min-h-screen">
        <SidebarNav />
        <main className="flex-1 p-4 pb-24 md:pb-6 max-w-5xl mx-auto w-full">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/escolas" element={<Escolas />} />
            <Route path="/escolas/:id" element={<EscolaDetalhe />} />
            <Route path="/turmas/:id" element={<TurmaDetalhe />} />
            <Route path="/scout/:id" element={<ModoJogo />} />
            <Route path="/relatorio/:id" element={<Relatorio />} />
            <Route path="/historico" element={<Historico />} />
            <Route path="/estatisticas" element={<Estatisticas />} />
            <Route path="/calendario" element={<Calendario />} />
            <Route path="/configuracoes" element={<Configuracoes />} />
            <Route path="/auth/login" element={<Login />} />
            <Route path="/auth/cadastro" element={<Cadastro />} />
            <Route path="/auth/recuperar-senha" element={<RecuperarSenha />} />
            <Route path="/auth/redefinir-senha" element={<RedefinirSenha />} />
          </Routes>
        </main>
      </div>
      <BottomNav />
    </HashRouter>
  )
}
