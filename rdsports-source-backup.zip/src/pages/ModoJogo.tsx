import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useStore } from '../store'
import { Card, PageTitle } from '../components/ui'
import { registrarEvento, criarSet, setEstaFechado, partidaEstaFinalizada, resumoFormato } from '../scoutEngine'
import type { FundamentoScout, ResultadoEvento } from '../types'
import { Volleyball } from 'lucide-react'

const FUNDAMENTOS: { chave: FundamentoScout; label: string }[] = [
  { chave: 'saque', label: 'Saque' },
  { chave: 'recepcao', label: 'Recepção' },
  { chave: 'levantamento', label: 'Levantamento' },
  { chave: 'ataque', label: 'Ataque' },
  { chave: 'bloqueio', label: 'Bloqueio' },
  { chave: 'defesa', label: 'Defesa' },
]

// Levantamento e Recepção usam Bom/Médio/Erro (nunca fecham rally no "bom/médio" —
// só marcam estatística da jogadora). Os demais usam Acerto/Em jogo/Erro.
function opcoesPara(fundamento: FundamentoScout): { resultado: ResultadoEvento; label: string; cor: string }[] {
  if (fundamento === 'recepcao' || fundamento === 'levantamento' || fundamento === 'defesa') {
    return [
      { resultado: 'BOM', label: '🟢 Bom', cor: 'bg-green-600' },
      { resultado: 'MEDIO', label: '🔵 Médio', cor: 'bg-blue-600' },
      { resultado: 'ERRO', label: '🔴 Erro', cor: 'bg-red-600' },
    ]
  }
  return [
    { resultado: 'ACERTO', label: '+ Ponto', cor: 'bg-green-600' },
    { resultado: 'EM_JOGO', label: '= Em jogo', cor: 'bg-blue-600' },
    { resultado: 'ERRO', label: '- Erro', cor: 'bg-red-600' },
  ]
}

export default function ModoJogo() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { partidas, atualizarPartida, atletas } = useStore()
  const partidaEncontrada = partidas.find((p) => p.id === id)
  const [atletaSelecionada, setAtletaSelecionada] = useState<string | undefined>(undefined)

  if (!partidaEncontrada) return <p>Partida não encontrada.</p>
  const partida = partidaEncontrada

  const meusAtletas = atletas.filter((a) => a.turmaId === partida.turmaId && !a.deletedAt)
  const setAtual = partida.setsPartida[partida.setsPartida.length - 1] ?? criarSet(1)
  const setJaExiste = partida.setsPartida.length > 0
  const partidaId = partida.id
  const formato = partida.formato

  function persistirSet(novoSet: typeof setAtual) {
    const sets = setJaExiste ? [...partida.setsPartida.slice(0, -1), novoSet] : [novoSet]
    atualizarPartida(partidaId, { setsPartida: sets })
    return sets
  }

  function marcar(fundamento: FundamentoScout, resultado: ResultadoEvento) {
    const novoSet = registrarEvento(setAtual, fundamento, resultado, atletaSelecionada)
    const sets = persistirSet(novoSet)

    const vencedor = setEstaFechado(novoSet, formato)
    if (vencedor) {
      finalizarSet(sets, novoSet, vencedor)
    }
  }

  function finalizarSet(sets: typeof partida.setsPartida, setFechado: typeof setAtual, vencedor: 'CASA' | 'ADVERSARIO') {
    const setsFinalizados = sets.map((s) => (s.id === setFechado.id ? { ...s, finalizado: true, vencedor } : s))
    const setsGanhosCasa = setsFinalizados.filter((s) => s.vencedor === 'CASA').length
    const setsGanhosAdversario = setsFinalizados.filter((s) => s.vencedor === 'ADVERSARIO').length
    const acabou = partidaEstaFinalizada(formato, setsGanhosCasa, setsGanhosAdversario, setsFinalizados.length)

    if (acabou) {
      atualizarPartida(partidaId, { setsPartida: setsFinalizados, setsGanhosCasa, setsGanhosAdversario, status: 'FINALIZADA' })
      navigate(`/relatorio/${partidaId}`)
    } else {
      const proximo = criarSet(setsFinalizados.length + 1)
      atualizarPartida(partidaId, { setsPartida: [...setsFinalizados, proximo], setsGanhosCasa, setsGanhosAdversario })
    }
  }

  return (
    <div>
      <PageTitle
        icon={<Volleyball size={22} />}
        title={partida.tipo === 'JOGO' ? `vs ${partida.adversarioNome ?? 'Adversário'}` : 'Treino'}
        subtitle={resumoFormato(partida)}
      />

      <Card className="mb-4 flex items-center justify-between">
        <div className="text-3xl font-black">{setAtual.placarCasa} <span className="text-[var(--rd-text-dim)] text-xl">×</span> {setAtual.placarAdversario}</div>
        <div className="text-sm text-[var(--rd-text-dim)]">
          Set {setAtual.numero} • {partida.setsGanhosCasa} × {partida.setsGanhosAdversario} sets
        </div>
      </Card>

      {meusAtletas.length > 0 && (
        <Card className="mb-4">
          <div className="text-xs font-semibold mb-2 text-[var(--rd-text-dim)]">Atleta em ação (opcional)</div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setAtletaSelecionada(undefined)}
              className={`rd-btn text-xs ${!atletaSelecionada ? 'rd-btn-gold' : ''}`}
            >Nenhuma</button>
            {meusAtletas.map((a) => (
              <button
                key={a.id}
                onClick={() => setAtletaSelecionada(a.id)}
                className={`rd-btn text-xs ${atletaSelecionada === a.id ? 'rd-btn-gold' : ''}`}
              >{a.nome}</button>
            ))}
          </div>
        </Card>
      )}

      <div className="grid sm:grid-cols-2 gap-3">
        {FUNDAMENTOS.map((f) => (
          <Card key={f.chave}>
            <div className="font-semibold mb-2">{f.label}</div>
            <div className="flex gap-2">
              {opcoesPara(f.chave).map((op) => (
                <button
                  key={op.resultado}
                  onClick={() => marcar(f.chave, op.resultado)}
                  className={`flex-1 rounded-lg py-2 text-sm font-semibold text-white ${op.cor}`}
                >
                  {op.label}
                </button>
              ))}
            </div>
          </Card>
        ))}
      </div>

      <p className="text-xs text-[var(--rd-text-dim)] mt-4">
        Levantamento e Recepção "Bom"/"Médio" só contam como estatística — não somam ponto nem fecham o rally.
      </p>
    </div>
  )
}
