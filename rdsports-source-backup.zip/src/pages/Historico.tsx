import { Link } from 'react-router-dom'
import { Trophy } from 'lucide-react'
import { useStore } from '../store'
import { PageTitle, Card, EmptyState } from '../components/ui'

export default function Historico() {
  const { partidas } = useStore()
  const lista = partidas.filter((p) => !p.deletedAt).sort((a, b) => b.data.localeCompare(a.data))

  return (
    <div>
      <PageTitle icon={<Trophy size={22} />} title="Histórico" subtitle={`${lista.length} registro(s)`} />
      {lista.length === 0 ? (
        <EmptyState icon={<Trophy size={40} />} text="Nenhum jogo ou treino registrado ainda." />
      ) : (
        <div className="grid gap-3">
          {lista.map((p) => (
            <Link key={p.id} to={`/relatorio/${p.id}`}>
              <Card className="flex items-center justify-between hover:brightness-95">
                <div>
                  <div className="font-semibold">{p.tipo === 'JOGO' ? `vs ${p.adversarioNome ?? 'Adversário'}` : 'Treino'}</div>
                  <div className="text-xs text-[var(--rd-text-dim)]">{p.data}</div>
                </div>
                <div className="text-sm font-semibold">{p.setsGanhosCasa} × {p.setsGanhosAdversario}</div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
