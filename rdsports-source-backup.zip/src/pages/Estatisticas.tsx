import { BarChart3 } from 'lucide-react'
import { useStore } from '../store'
import { PageTitle, Card, EmptyState } from '../components/ui'

export default function Estatisticas() {
  const { partidas, atletas } = useStore()
  const finalizadas = partidas.filter((p) => p.status === 'FINALIZADA' && !p.deletedAt)

  if (finalizadas.length === 0) {
    return (
      <div>
        <PageTitle icon={<BarChart3 size={22} />} title="Estatísticas" />
        <EmptyState icon={<BarChart3 size={40} />} text="Ainda não há partidas finalizadas pra gerar estatísticas." />
      </div>
    )
  }

  // Contagem simples de eventos por fundamento (agregado de todas as partidas).
  const contagem: Record<string, { bom: number; erro: number }> = {}
  for (const p of finalizadas) {
    for (const s of p.setsPartida) {
      for (const r of s.rallies) {
        for (const ev of r.eventos) {
          contagem[ev.fundamento] ??= { bom: 0, erro: 0 }
          if (ev.resultado === 'ERRO') contagem[ev.fundamento].erro++
          else contagem[ev.fundamento].bom++
        }
      }
    }
  }

  return (
    <div>
      <PageTitle icon={<BarChart3 size={22} />} title="Estatísticas" subtitle={`${finalizadas.length} partida(s) finalizada(s) • ${atletas.length} atleta(s)`} />
      <div className="grid sm:grid-cols-2 gap-3">
        {Object.entries(contagem).map(([fundamento, c]) => (
          <Card key={fundamento}>
            <div className="font-semibold capitalize">{fundamento}</div>
            <div className="text-sm text-[var(--rd-text-dim)]">{c.bom} bons/acertos • {c.erro} erros</div>
          </Card>
        ))}
      </div>
    </div>
  )
}
