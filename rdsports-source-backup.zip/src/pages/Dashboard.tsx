import { Volleyball, Calendar, Trophy } from 'lucide-react'
import { useStore } from '../store'
import { PageTitle, Card, EmptyState } from '../components/ui'
import { parseDataLocal, aproveitamento } from '../utils'
import { Link } from 'react-router-dom'

export default function Dashboard() {
  const { escolas, turmas, atletas, partidas, jogosAgendados } = useStore()

  const hoje = new Date(new Date().toDateString())
  const proximosJogos = jogosAgendados
    .filter((j) => !j.deletedAt && parseDataLocal(j.data) >= hoje)
    .sort((a, b) => a.data.localeCompare(b.data))
    .slice(0, 5)

  const ultimosResultados = partidas
    .filter((p) => p.tipo === 'JOGO' && p.status === 'FINALIZADA' && !p.deletedAt)
    .sort((a, b) => b.data.localeCompare(a.data))
    .slice(0, 5)

  const kpis = [
    { label: 'Escolas', valor: escolas.filter((e) => !e.deletedAt).length },
    { label: 'Turmas', valor: turmas.filter((t) => !t.deletedAt).length },
    { label: 'Atletas', valor: atletas.filter((a) => !a.deletedAt).length },
    { label: 'Jogos', valor: partidas.filter((p) => p.tipo === 'JOGO' && !p.deletedAt).length },
    { label: 'Aproveitamento', valor: `${aproveitamento(partidas)}%` },
  ]

  const hora = new Date().getHours()
  const saudacao = hora < 12 ? 'Bom dia' : hora < 18 ? 'Boa tarde' : 'Boa noite'

  return (
    <div>
      <PageTitle icon={<Volleyball size={24} strokeWidth={2.25} />} title={`${saudacao}!`} subtitle="Visão geral do RDSports" />

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        {kpis.map((k) => (
          <Card key={k.label} className="text-center">
            <div className="text-2xl font-black rd-accent-text">{k.valor}</div>
            <div className="text-xs text-[var(--rd-text-dim)] mt-1">{k.label}</div>
          </Card>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <h2 className="font-bold flex items-center gap-2 mb-2"><Calendar size={18} /> Próximos jogos</h2>
          {proximosJogos.length === 0 ? (
            <EmptyState icon={<Calendar size={40} />} text="Nenhum jogo agendado ainda." />
          ) : (
            <div className="flex flex-col gap-2">
              {proximosJogos.map((j) => (
                <Card key={j.id}>
                  <div className="font-semibold">vs {j.adversarioNome}</div>
                  <div className="text-sm text-[var(--rd-text-dim)]">{j.data} {j.horario ?? ''} {j.local ? `• ${j.local}` : ''}</div>
                </Card>
              ))}
            </div>
          )}
        </div>
        <div>
          <h2 className="font-bold flex items-center gap-2 mb-2"><Trophy size={18} /> Últimos resultados</h2>
          {ultimosResultados.length === 0 ? (
            <EmptyState icon={<Trophy size={40} />} text="Nenhum jogo finalizado ainda." />
          ) : (
            <div className="flex flex-col gap-2">
              {ultimosResultados.map((p) => (
                <Link key={p.id} to={`/relatorio/${p.id}`}>
                  <Card className="hover:brightness-95">
                    <div className="font-semibold">vs {p.adversarioNome ?? 'Adversário'}</div>
                    <div className="text-sm text-[var(--rd-text-dim)]">{p.setsGanhosCasa} × {p.setsGanhosAdversario} sets — {p.data}</div>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
