import { useState } from 'react'
import { Calendar as CalendarIcon, Plus } from 'lucide-react'
import { useStore } from '../store'
import { PageTitle, Card, Button, EmptyState, Field } from '../components/ui'
import { gerarOcorrenciasTreino, parseDataLocal, isoDia } from '../utils'

export default function Calendario() {
  const { turmas, jogosAgendados, horariosTreino, addJogoAgendado, addAdversario } = useStore()
  const [adversario, setAdversario] = useState('')
  const [data, setData] = useState('')
  const [turmaId, setTurmaId] = useState(turmas[0]?.id ?? '')

  const hoje = new Date(new Date().toDateString())
  const jogos = jogosAgendados
    .filter((j) => !j.deletedAt && parseDataLocal(j.data) >= hoje)
    .map((j) => ({ tipo: 'JOGO' as const, data: j.data, titulo: `vs ${j.adversarioNome}`, local: j.local }))
  const treinos = gerarOcorrenciasTreino(horariosTreino, 30)
    .filter((o) => parseDataLocal(o.data) >= hoje)
    .map((o) => ({ tipo: 'TREINO' as const, data: o.data, titulo: 'Treino', local: o.local }))

  const eventos = [...jogos, ...treinos].sort((a, b) => a.data.localeCompare(b.data))

  function agendar() {
    if (!adversario.trim() || !data || !turmaId) return
    const adv = addAdversario(adversario.trim())
    addJogoAgendado({ turmaId, adversarioId: adv.id, adversarioNome: adv.nome, data })
    setAdversario(''); setData('')
  }

  return (
    <div>
      <PageTitle icon={<CalendarIcon size={22} />} title="Calendário" subtitle="Jogos agendados e treinos recorrentes" />

      <Card className="mb-5">
        <div className="grid sm:grid-cols-3 gap-2">
          <Field label="Turma">
            <select className="rd-input" value={turmaId} onChange={(e) => setTurmaId(e.target.value)}>
              {turmas.map((t) => <option key={t.id} value={t.id}>{t.nome}</option>)}
            </select>
          </Field>
          <Field label="Adversário">
            <input className="rd-input" value={adversario} onChange={(e) => setAdversario(e.target.value)} placeholder="Nome do adversário" />
          </Field>
          <Field label="Data">
            <input className="rd-input" type="date" value={data} onChange={(e) => setData(e.target.value)} min={isoDia(new Date())} />
          </Field>
        </div>
        <Button variant="gold" onClick={agendar}><Plus size={16} /> Agendar jogo</Button>
      </Card>

      {eventos.length === 0 ? (
        <EmptyState icon={<CalendarIcon size={40} />} text="Nenhum evento futuro." />
      ) : (
        <div className="grid gap-2">
          {eventos.map((ev, i) => (
            <Card key={i} className="flex items-center justify-between">
              <span>{ev.tipo === 'JOGO' ? '🏐' : '🏃'} {ev.titulo}</span>
              <span className="text-sm text-[var(--rd-text-dim)]">{ev.data}{ev.local ? ` • ${ev.local}` : ''}</span>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
