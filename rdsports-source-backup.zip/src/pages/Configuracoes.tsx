import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Settings, Cloud, LogOut, RefreshCw } from 'lucide-react'
import { PageTitle, Card, Button } from '../components/ui'
import { useAuthStore } from '../authStore'
import { useStore } from '../store'
import { pullAll } from '../cloudSync'

export default function Configuracoes() {
  const { user, carregando, sair } = useAuthStore()
  const mesclarDaNuvem = useStore((s) => s.mesclarDaNuvem)
  const [sincronizando, setSincronizando] = useState(false)
  const [mensagem, setMensagem] = useState<string | null>(null)

  async function buscarAgora() {
    setSincronizando(true)
    setMensagem(null)
    try {
      const dados = await pullAll()
      if (dados) {
        mesclarDaNuvem(dados)
        setMensagem('Dados atualizados a partir da nuvem.')
      }
    } catch {
      setMensagem('Não foi possível buscar agora — verifique a conexão.')
    } finally {
      setSincronizando(false)
    }
  }

  return (
    <div>
      <PageTitle icon={<Settings size={22} />} title="Configurações" />

      <Card className="mb-5">
        <div className="flex items-center gap-2 font-semibold mb-2">
          <Cloud size={18} className="rd-accent-text" /> Conta na nuvem
        </div>
        {carregando ? (
          <p className="text-sm text-[var(--rd-text-dim)]">Carregando…</p>
        ) : user ? (
          <div>
            <p className="text-sm mb-3">Conectado como <strong>{user.email}</strong>. Seus dados estão sincronizados com todos os aparelhos logados nesta conta.</p>
            <div className="flex gap-2 flex-wrap">
              <Button onClick={buscarAgora} disabled={sincronizando}>
                <RefreshCw size={16} className={sincronizando ? 'animate-spin' : ''} /> Buscar atualização agora
              </Button>
              <Button variant="danger" onClick={() => sair()}><LogOut size={16} /> Sair</Button>
            </div>
            {mensagem && <p className="text-xs text-[var(--rd-text-dim)] mt-2">{mensagem}</p>}
          </div>
        ) : (
          <div>
            <p className="text-sm text-[var(--rd-text-dim)] mb-3">
              Entre com sua conta pra sincronizar os dados entre todos os seus aparelhos e recuperar os dados
              que já existiam na nuvem.
            </p>
            <div className="flex gap-2">
              <Link to="/auth/login"><Button variant="gold">Entrar</Button></Link>
              <Link to="/auth/cadastro"><Button>Criar conta</Button></Link>
            </div>
          </div>
        )}
      </Card>

      <Card>
        <p className="text-sm text-[var(--rd-text-dim)]">
          Versão reconstruída do RDSports após a perda do código-fonte original. Algumas páginas das rodadas
          anteriores (lembretes, documentos, avaliações periódicas detalhadas, campeonatos avançados, busca
          global e lixeira) ainda serão trazidas de volta nas próximas atualizações.
        </p>
      </Card>
    </div>
  )
}
