import { useParams, Link } from 'react-router-dom'
import { useStore } from '../store'
import { PageTitle, Card } from '../components/ui'
import { Trophy } from 'lucide-react'
import { resumoFormato } from '../scoutEngine'

export default function Relatorio() {
  const { id } = useParams()
  const { partidas } = useStore()
  const partida = partidas.find((p) => p.id === id)
  if (!partida) return <p>Partida não encontrada.</p>

  return (
    <div>
      <PageTitle icon={<Trophy size={22} />} title={`vs ${partida.adversarioNome ?? 'Adversário'}`} subtitle={`${partida.data} • ${resumoFormato(partida)}`} />

      <Card className="mb-4 text-center">
        <div className="text-4xl font-black">{partida.setsGanhosCasa} × {partida.setsGanhosAdversario}</div>
        <div className="text-sm text-[var(--rd-text-dim)] mt-1">{partida.status === 'FINALIZADA' ? 'Finalizada' : 'Em andamento'}</div>
      </Card>

      <div className="grid gap-3">
        {partida.setsPartida.map((s) => (
          <Card key={s.id} className="flex items-center justify-between">
            <span className="font-semibold">Set {s.numero}</span>
            <span>{s.placarCasa} × {s.placarAdversario}</span>
            <span className="text-xs text-[var(--rd-text-dim)]">{s.vencedor ? (s.vencedor === 'CASA' ? 'Vencemos' : 'Perdemos') : '—'}</span>
          </Card>
        ))}
      </div>

      <Link to="/historico" className="inline-block mt-4 text-sm text-[var(--rd-text-dim)] underline">← Voltar pro Histórico</Link>
    </div>
  )
}
