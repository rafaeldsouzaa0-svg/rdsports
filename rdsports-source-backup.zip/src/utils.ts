import type { HorarioTreino, Partida, Rally } from './types'

/** Sempre usar isso pra formatar/comparar datas "YYYY-MM-DD" com "hoje" — nunca
 *  `new Date(str)` puro, que o JS interpreta em UTC e causa o bug de fuso horário
 *  (Brasil é UTC-3) já corrigido antes: um jogo "de hoje" desaparecia dos filtros. */
export function parseDataLocal(d: string): Date {
  return new Date(`${d}T00:00:00`)
}

export function isoDia(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function formatDate(d: string): string {
  const dt = parseDataLocal(d)
  return dt.toLocaleDateString('pt-BR')
}

export function gerarOcorrenciasTreino(horarios: HorarioTreino[], diasAFrente = 45) {
  const ocorrencias: { horarioId: string; turmaId: string; data: string; horario: string; local?: string }[] = []
  const hoje = new Date(new Date().toDateString())
  for (let i = 0; i < diasAFrente; i++) {
    const dia = new Date(hoje); dia.setDate(dia.getDate() + i)
    const diaSemana = dia.getDay()
    for (const h of horarios) {
      if (h.deletedAt) continue
      if (h.diaSemana === diaSemana) {
        ocorrencias.push({ horarioId: h.id, turmaId: h.turmaId, data: isoDia(dia), horario: h.horario, local: h.local })
      }
    }
  }
  return ocorrencias
}

export function uid(): string {
  return crypto.randomUUID()
}

export function nowISO(): string {
  return new Date().toISOString()
}

/** Conta pontos de um lado a partir dos rallies de um set — só o rally que
 *  efetivamente fecha o ponto (encerraRally) conta; fundamentos como Recepção e
 *  Levantamento nunca fecham rally sozinhos, então nunca aparecem aqui. */
export function totalPontos(rallies: Rally[], lado: 'CASA' | 'ADVERSARIO'): number {
  return rallies.filter((r) => (lado === 'CASA' ? r.pontoCasa : !r.pontoCasa)).length
}

export function aproveitamento(partidas: Partida[]): number {
  const finalizadas = partidas.filter((p) => p.tipo === 'JOGO' && p.status === 'FINALIZADA' && !p.deletedAt)
  if (finalizadas.length === 0) return 0
  const vitorias = finalizadas.filter((p) => p.setsGanhosCasa > p.setsGanhosAdversario).length
  return Math.round((vitorias / finalizadas.length) * 100)
}
