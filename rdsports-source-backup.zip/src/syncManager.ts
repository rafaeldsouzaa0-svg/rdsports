// Liga a sessão de autenticação (authStore) ao motor de sincronização (cloudSync)
// com o store principal (store.ts). Chamado uma vez em App.tsx.
//
// - Ao logar: puxa tudo da nuvem e mescla no local (recuperação dos dados antigos).
// - Enquanto logado: empurra qualquer mudança local pra nuvem (debounce de 3s) e
//   puxa periodicamente (a cada 25s) pra pegar o que outros aparelhos mandaram —
//   simples e "com o app aberto", mesmo espírito já usado nos Lembretes (Rodada 47).
import { useAuthStore } from './authStore'
import { useStore } from './store'
import { pullAll, pushAll } from './cloudSync'

let debounceTimer: ReturnType<typeof setTimeout> | null = null
let pollTimer: ReturnType<typeof setInterval> | null = null
let unsubscribeStore: (() => void) | null = null
let sincronizando = false
let logadoAtual = false

async function puxarEMesclar() {
  try {
    const dados = await pullAll()
    if (dados) useStore.getState().mesclarDaNuvem(dados)
  } catch (err) {
    console.warn('[sync] falha ao puxar da nuvem', err)
  }
}

function agendarPush() {
  if (debounceTimer) clearTimeout(debounceTimer)
  debounceTimer = setTimeout(async () => {
    if (sincronizando) return
    sincronizando = true
    try {
      const s = useStore.getState()
      await pushAll({
        escolas: s.escolas, turmas: s.turmas, atletas: s.atletas, adversarios: s.adversarios,
        campeonatos: s.campeonatos, partidas: s.partidas, jogosAgendados: s.jogosAgendados, avaliacoes: s.avaliacoes,
      })
    } catch (err) {
      console.warn('[sync] falha ao empurrar pra nuvem', err)
    } finally {
      sincronizando = false
    }
  }, 3000)
}

function pararSync() {
  if (unsubscribeStore) { unsubscribeStore(); unsubscribeStore = null }
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null }
  if (debounceTimer) { clearTimeout(debounceTimer); debounceTimer = null }
}

async function iniciarSync() {
  await puxarEMesclar()
  unsubscribeStore = useStore.subscribe(() => agendarPush())
  pollTimer = setInterval(puxarEMesclar, 25000)

  const flush = () => { if (debounceTimer) { clearTimeout(debounceTimer); debounceTimer = null } }
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush() })
  window.addEventListener('pagehide', flush)
}

export function initSyncManager() {
  useAuthStore.getState().init()
  useAuthStore.subscribe((state) => {
    const logado = !!state.user
    if (logado && !logadoAtual) {
      logadoAtual = true
      iniciarSync()
    } else if (!logado && logadoAtual) {
      logadoAtual = false
      pararSync()
    }
  })
  // Caso já exista sessão restaurada antes do primeiro subscribe disparar:
  setTimeout(() => {
    if (useAuthStore.getState().user && !logadoAtual) {
      logadoAtual = true
      iniciarSync()
    }
  }, 300)
}
